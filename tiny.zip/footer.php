		<footer>
		<p>&copy;<?php echo(date('Y')); ?>. Wordpress <?php bloginfo('version'); ?> running the <a href="http://tjsdesigned.com">tiny</a> theme.</p>
		<!--<script type='text/javascript'>(function(){document.write("<img id='boston' src='http://bostonbuilt.org/icon.php?q=b_logo_small.png&u=" + window.location.host + "' />");})();</script></script>--></footer>
	</body>
</html>